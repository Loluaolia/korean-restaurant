from django.shortcuts import render
from .models import Product, Category

def dish_list(request):
    products = Product.objects.all()
    categories = Category.objects.all()
    selected_category_ids = request.GET.getlist('category')
    if selected_category_ids:
        products = products.filter(category__id__in=selected_category_ids)
    selected_spiciness = request.GET.get('spiciness', 0)
    if int(selected_spiciness) > 0:
        products = products.filter(spiciness__gte=selected_spiciness)
    contains_nuts = request.GET.get('nuts')
    if contains_nuts == 'on':
        products = products.filter(nuts=True)
    is_vegetarian = request.GET.get('vegetarian')
    if is_vegetarian == 'on':
        products = products.filter(vegetarian=True)

    context = {
        'dishes': products,
        'categories': categories,
        'selected_category_ids': [int(cat_id) for cat_id in selected_category_ids],
        'selected_spiciness': int(selected_spiciness),
        'contains_nuts': contains_nuts,
        'is_vegetarian': is_vegetarian,
    }
    
    return render(request, 'products/dish_list.html', context)