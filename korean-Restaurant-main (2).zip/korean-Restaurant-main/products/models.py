from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True)

    def __str__(self):
        return self.name
class Product(models.Model):
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    category = models.ForeignKey(Category, related_name='products', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='products/', blank=True)    
    spiciness = models.IntegerField(default=0, help_text='Spiciness level from 0 (not spicy) to 5 (very spicy)')
    nuts = models.BooleanField(default=False, help_text='Contains nuts')
    vegetarian = models.BooleanField(default=False, help_text='Vegetarian option')
    def __str__(self):
        return self.name
