from django.urls import path
from .views import dish_list
app_name = 'products'

urlpatterns = [
    path('', dish_list, name='dish_list'), 
]