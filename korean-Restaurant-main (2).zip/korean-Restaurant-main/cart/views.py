from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from products.models import Product
from .models import Cart, CartItem

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    user_cart, created = Cart.objects.get_or_create(user=request.user)
    cart_item, created = CartItem.objects.get_or_create(
        cart=user_cart,
        product=product
    )
    if not created:
        cart_item.quantity += 1
        cart_item.save()    
    return redirect('products:dish_list')

@login_required
def remove_from_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    user_cart = Cart.objects.get(user=request.user)
    CartItem.objects.filter(cart=user_cart, product=product).delete()
    messages.success(request, f"'{product.name}' removed from your cart.")
    
    return redirect('cart:cart_detail')

@login_required
def cart_detail(request):
    user_cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = user_cart.items.all()
    
    total_price = sum(item.subtotal for item in cart_items)

    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }
    return render(request, 'cart/cart_detail.html', context)


@login_required
def pay(request):
    user_cart = Cart.objects.get(user=request.user)
    if not user_cart.items.exists():
        messages.error(request, "Your cart is empty.")
        return redirect('cart:cart_detail')
    user_cart.items.all().delete()

    messages.success(request, "You've successfully purchased the items!")
    return redirect('products:dish_list')